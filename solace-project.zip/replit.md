# Solace

A warm, unhurried AI companion chat app for people who are grieving — not a therapist, just a gentle presence to sit with someone's feelings.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server
- `pnpm --filter @workspace/solace run dev` — run the Solace web frontend
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- Required env: `OPENAI_API_KEY` — actually holds a Groq API key (see Gotchas)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- Frontend: React + Vite (`artifacts/solace`)
- Validation: Zod (`zod/v4`)
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Chat completions: `openai` npm SDK pointed at Groq's OpenAI-compatible endpoint

## Where things live

- `artifacts/solace` — the Solace web frontend (welcome screen, chat UI, streaming hook)
- `artifacts/api-server/src/routes/chat.ts` — `/api/chat/messages` SSE streaming endpoint and system prompt
- `lib/api-spec/openapi.yaml` — source of truth for the `/chat/messages` contract (request schema only; SSE response isn't Orval-typed)

## Architecture decisions

- Chat is stateless server-side — the client holds full message history in state and resends it each turn; no DB persistence.
- The `/chat/messages` endpoint streams via raw SSE (`text/event-stream`), consumed on the frontend with manual `fetch` + `ReadableStream` parsing rather than the generated React Query hook, since Orval can't type streaming responses.
- Chat completions go through the `openai` SDK but with `baseURL` set to Groq's endpoint (see Gotchas) — this is not the Replit AI Integrations proxy.

## Product

- Gentle name-entry welcome screen (name optional)
- Chat screen with pre-written gentle conversation starters, streaming replies, typing indicator, and a tasteful non-therapy disclaimer

## User preferences

- Declined the Replit AI Integrations OpenAI upgrade; use the user's own API key with the standard SDK directly instead.

## Gotchas

- The `OPENAI_API_KEY` secret actually contains a **Groq** key (`gsk_...` prefix), not a real OpenAI key. The OpenAI SDK client in `chat.ts` is configured with `baseURL: "https://api.groq.com/openai/v1"` and uses Groq model names (e.g. `llama-3.3-70b-versatile`). Do not swap in real OpenAI model names or drop the custom baseURL.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
