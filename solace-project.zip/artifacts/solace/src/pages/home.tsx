import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { WelcomeScreen } from '@/components/welcome-screen';
import { ChatScreen } from '@/components/chat-screen';

export default function Home() {
  const [hasStarted, setHasStarted] = useState(false);
  const [userName, setUserName] = useState<string | undefined>();

  const handleStart = (name?: string) => {
    setUserName(name);
    setHasStarted(true);
  };

  const handleHome = () => {
    setHasStarted(false);
  };

  return (
    <main className="min-h-[100dvh] bg-background text-foreground selection:bg-primary/20">
      <AnimatePresence mode="wait">
        {!hasStarted ? (
          <motion.div
            key="welcome"
            exit={{ opacity: 0, filter: 'blur(10px)' }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="absolute inset-0"
          >
            <WelcomeScreen onStart={handleStart} />
          </motion.div>
        ) : (
          <motion.div
            key="chat"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 2, ease: "easeInOut", delay: 0.5 }}
            className="absolute inset-0"
          >
            <ChatScreen name={userName} onHome={handleHome} />
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
