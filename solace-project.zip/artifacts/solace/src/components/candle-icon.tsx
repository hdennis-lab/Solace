import React from 'react';

export function CandleIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path
        className="candle-flame"
        d="M12 2C12 2 9.5 4.8 9.5 6.6C9.5 7.98 10.62 9 12 9C13.38 9 14.5 7.98 14.5 6.6C14.5 4.8 12 2 12 2Z"
        fill="currentColor"
        opacity="0.85"
      />
      <rect
        x="9"
        y="10.5"
        width="6"
        height="10.5"
        rx="1.2"
        fill="currentColor"
        opacity="0.55"
      />
      <rect
        x="9"
        y="10.5"
        width="6"
        height="10.5"
        rx="1.2"
        stroke="currentColor"
        strokeWidth="1"
        opacity="0.9"
      />
    </svg>
  );
}
