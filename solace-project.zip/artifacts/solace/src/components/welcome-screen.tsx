import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { CandleIcon } from '@/components/candle-icon';

export function WelcomeScreen({ onStart }: { onStart: (name?: string) => void }) {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStart(name.trim() || undefined);
  };

  return (
    <div className="min-h-[100dvh] flex flex-col items-center justify-center p-6 bg-background relative overflow-hidden">
      {/* Soft background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80vw] h-[80vw] max-w-[600px] max-h-[600px] bg-primary/5 rounded-full blur-[100px] pointer-events-none" />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2, ease: [0.23, 1, 0.32, 1] }}
        className="w-full max-w-md text-center z-10"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.4, ease: [0.23, 1, 0.32, 1] }}
          className="flex justify-center mb-6"
        >
          <CandleIcon className="w-10 h-10 text-primary" />
        </motion.div>

        <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif text-foreground mb-8">Solace</h1>
        
        <p className="text-lg md:text-xl text-muted-foreground font-serif leading-relaxed mb-12 max-w-sm mx-auto">
          A quiet place to sit with your feelings. No judgment, no rushing, no trying to fix things.
        </p>

        <form onSubmit={handleSubmit} className="space-y-8 max-w-xs mx-auto">
          <div className="space-y-4">
            <label htmlFor="name-input" className="text-sm text-foreground/70 block">
              If you'd like, you can tell me your name.
            </label>
            <Input
              id="name-input"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name (optional)"
              className="text-center text-lg py-6 bg-transparent border-0 border-b border-border rounded-none focus-visible:ring-0 focus-visible:border-primary placeholder:text-muted-foreground/40 transition-colors"
            />
          </div>
          
          <button
            type="submit"
            className="text-primary hover:text-primary-foreground hover:bg-primary px-8 py-3 rounded-full transition-all duration-500 ease-out"
          >
            Enter softly
          </button>
        </form>
      </motion.div>
    </div>
  );
}
