import React from 'react';
import { motion } from 'framer-motion';
import { Message } from '@/hooks/use-chat';

export function ChatMessage({ message }: { message: Message }) {
  const isUser = message.role === 'user';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
      className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'} my-6`}
    >
      <div
        className={`max-w-[85%] md:max-w-[75%] ${
          isUser
            ? 'bg-secondary text-secondary-foreground px-5 py-4 rounded-2xl rounded-tr-sm shadow-sm'
            : 'text-foreground'
        }`}
      >
        {!isUser && <div className="text-xs font-serif text-muted-foreground mb-2 px-1">Solace</div>}
        <div className={`prose prose-stone dark:prose-invert max-w-none text-base md:text-lg leading-relaxed ${isUser ? 'text-secondary-foreground' : 'text-foreground font-serif'}`}>
          {message.content.split('\n').map((paragraph, index) => (
            <p key={index} className={index !== 0 ? 'mt-4' : ''}>
              {paragraph}
            </p>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
