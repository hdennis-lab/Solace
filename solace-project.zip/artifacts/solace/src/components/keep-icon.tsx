import React from 'react';

export function KeepIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M7 3.5H17C17.2761 3.5 17.5 3.72386 17.5 4V20.2C17.5 20.62 17.0353 20.8724 16.6822 20.6404L12.2704 17.7448C12.1069 17.6376 11.8931 17.6376 11.7296 17.7448L7.31776 20.6404C6.96467 20.8724 6.5 20.62 6.5 20.2V4C6.5 3.72386 6.72386 3.5 7 3.5Z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
        fill="currentColor"
        fillOpacity="0.12"
      />
    </svg>
  );
}
