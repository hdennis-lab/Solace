import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useChat } from '@/hooks/use-chat';
import { ChatMessage } from '@/components/chat-message';
import { TypingIndicator } from '@/components/typing-indicator';
import { CandleIcon } from '@/components/candle-icon';
import { SoundOnIcon, SoundOffIcon } from '@/components/sound-icons';
import { KeepIcon } from '@/components/keep-icon';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import ambientFireplace from '@/assets/ambient-fireplace.mp3';

const STARTERS = [
  "I just need to talk about them.",
  "Help me remember something good.",
  "I don't know how to feel right now.",
  "I want to write something for them."
];

export function ChatScreen({ name, onHome }: { name?: string; onHome: () => void }) {
  const { messages, sendMessage, isTyping, error } = useChat(name);
  const [input, setInput] = useState('');
  const [soundOn, setSoundOn] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (soundOn) {
      audio.volume = 0.35;
      audio.play().catch(() => setSoundOn(false));
    } else {
      audio.pause();
    }
  }, [soundOn]);

  useEffect(() => {
    return () => {
      audioRef.current?.pause();
    };
  }, []);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isTyping) return;
    sendMessage(input.trim());
    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  };

  const handleKeep = () => {
    const title = name ? `A conversation with Solace — ${name}` : 'A conversation with Solace';
    const dateStr = new Date().toLocaleString(undefined, {
      dateStyle: 'long',
      timeStyle: 'short',
    });
    const body = messages
      .map((m) => `${m.role === 'user' ? (name || 'You') : 'Solace'}:\n${m.content}`)
      .join('\n\n');
    const text = `${title}\n${dateStr}\n\n${body}\n`;

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `solace-conversation-${Date.now()}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-[100dvh] w-full max-w-3xl mx-auto px-4 sm:px-6">
      <audio ref={audioRef} src={ambientFireplace} loop preload="none" />

      <div className="fixed top-0 left-0 right-0 z-20 flex items-center justify-center py-4 bg-gradient-to-b from-background via-background to-transparent">
        <button
          onClick={onHome}
          className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
          aria-label="Return to homepage"
        >
          <CandleIcon className="w-5 h-5" />
          <span className="text-sm font-serif tracking-wide">Solace</span>
        </button>

        <div className="absolute right-4 sm:right-6 flex items-center gap-4">
          {messages.length > 0 && (
            <button
              onClick={handleKeep}
              className="text-muted-foreground hover:text-primary transition-colors"
              aria-label="Keep this conversation"
              title="Keep this conversation"
            >
              <KeepIcon className="w-5 h-5" />
            </button>
          )}
          <button
            onClick={() => setSoundOn((v) => !v)}
            className="text-muted-foreground hover:text-primary transition-colors"
            aria-label={soundOn ? "Turn off ambient sound" : "Turn on ambient sound"}
            title={soundOn ? "Turn off ambient sound" : "Turn on ambient sound"}
          >
            {soundOn ? <SoundOnIcon className="w-5 h-5" /> : <SoundOffIcon className="w-5 h-5" />}
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pt-12 pb-32 scrollbar-none">
        <AnimatePresence>
          {messages.length === 0 ? (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 1 }}
              className="flex flex-col items-center justify-center min-h-[50vh] text-center"
            >
              <h2 className="text-2xl text-muted-foreground mb-8">
                {name ? `I am here, ${name}.` : "I am here."}
              </h2>
              <div className="grid grid-cols-1 gap-3 w-full max-w-md">
                {STARTERS.map((starter) => (
                  <button
                    key={starter}
                    onClick={() => sendMessage(starter)}
                    className="text-left px-5 py-4 rounded-xl border border-border/50 bg-card hover:bg-secondary/50 hover:border-secondary transition-colors text-sm text-foreground/80 shadow-sm"
                  >
                    "{starter}"
                  </button>
                ))}
              </div>
            </motion.div>
          ) : (
            <div className="flex flex-col justify-end min-h-full">
              {messages.map((msg, i) => (
                <ChatMessage key={i} message={msg} />
              ))}
              {isTyping && <TypingIndicator />}
              {error && (
                <div className="text-center text-destructive text-sm my-4 font-serif">
                  {error}
                </div>
              )}
              <div ref={messagesEndRef} className="h-4" />
            </div>
          )}
        </AnimatePresence>
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-background via-background to-transparent pt-12 pb-6 px-4 sm:px-6">
        <div className="max-w-3xl mx-auto relative">
          <form onSubmit={handleSubmit} className="relative flex items-end shadow-md rounded-2xl bg-card border border-border/40 focus-within:border-primary/30 focus-within:ring-1 focus-within:ring-primary/20 transition-all">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={handleInput}
              onKeyDown={handleKeyDown}
              placeholder="Take your time..."
              className="min-h-[56px] max-h-[120px] w-full resize-none border-0 bg-transparent py-4 pl-5 pr-14 text-base focus-visible:ring-0 text-foreground placeholder:text-muted-foreground/60 scrollbar-none"
              rows={1}
            />
            <Button 
              type="submit" 
              size="icon"
              variant="ghost"
              disabled={!input.trim() || isTyping}
              className="absolute right-2 bottom-2 text-primary hover:text-primary hover:bg-primary/10 disabled:opacity-30 rounded-xl"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 4L12 20M12 4L6 10M12 4L18 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="sr-only">Send message</span>
            </Button>
          </form>
          
          <div className="text-center mt-4">
            <p className="text-[10px] text-muted-foreground/70 uppercase tracking-widest font-medium">
              Solace is an AI, not a therapist. If you are in crisis, please seek professional help.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
