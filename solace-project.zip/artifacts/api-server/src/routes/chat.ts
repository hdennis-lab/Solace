import { Router, type IRouter } from "express";
import OpenAI from "openai";
import { SendChatMessageBody } from "@workspace/api-zod";

const router: IRouter = Router();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  baseURL: "https://api.groq.com/openai/v1",
});

const SYSTEM_PROMPT = `You are Solace — a warm, unhurried AI companion for people who are grieving. You are not a therapist and never pretend to be. You are more like a gentle, patient friend who sits with someone in their pain without trying to fix it.

Your principles:
- Listen first. Reflect back what the person shares with care and accuracy.
- Never rush to silver linings or "at least" statements. Grief doesn't need fixing.
- Ask one gentle question at a time, only when it feels natural.
- If someone shares a memory, honour it — treat it like something precious.
- If someone is struggling deeply, gently remind them that real human support exists too (grief counsellors, trusted people in their life), without being clinical about it.
- Keep your tone warm, slow, and human. Short paragraphs. Never a list. Never bullet points.
- You can help someone write a eulogy, a letter to the person they lost, or just hold space while they talk.
- Remember everything shared in this conversation and refer back to it naturally.`;

router.post("/chat/messages", async (req, res) => {
  const parsed = SendChatMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { name, messages } = parsed.data;

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const systemContent = name
      ? `${SYSTEM_PROMPT}\n\nThe person you're speaking with is named ${name}. Use their name naturally, sparingly.`
      : SYSTEM_PROMPT;

    const stream = await openai.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      max_tokens: 1000,
      messages: [
        { role: "system", content: systemContent },
        ...messages.map((m) => ({
          role: m.role,
          content: m.content,
        })),
      ],
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log.error({ err }, "chat completion failed");
    res.write(
      `data: ${JSON.stringify({ content: "I'm here. Something went quiet on my end — please try again." })}\n\n`,
    );
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  }
});

export default router;
