---
name: Solace OPENAI_API_KEY is actually a Groq key
description: Explains why the Solace app's OpenAI SDK client points at Groq's baseURL despite the env var being named OPENAI_API_KEY.
---

When the user was asked for `OPENAI_API_KEY` (because Replit AI Integrations OpenAI upgrade was declined), the value they provided starts with `gsk_` — Groq's key prefix, not a real OpenAI key (`sk-...`).

**Why:** The original reference app for Solace used Groq's API. The user apparently reused/provided a Groq key under the `OPENAI_API_KEY` name. A plain `new OpenAI({ apiKey })` call against the default OpenAI base URL fails with 401 `invalid_api_key` even though the key itself is valid — because it's being sent to the wrong host.

**How to apply:** The OpenAI SDK is fully compatible with Groq via `baseURL: "https://api.groq.com/openai/v1"`. Instantiate the client as:
```ts
new OpenAI({ apiKey: process.env.OPENAI_API_KEY, baseURL: "https://api.groq.com/openai/v1" })
```
and use Groq model names (e.g. `llama-3.3-70b-versatile`), not OpenAI model names like `gpt-4o`. If a future session sees an `OPENAI_API_KEY` secret starting with `gsk_`, treat it as a Groq key and route accordingly rather than assuming it's broken.
